﻿Public Class frmComputer
    Dim nume As String = "Player"
    Dim scorX As Integer = 0 'contorizeaza scorul Playerului 1
    Dim scor0 As Integer = 0 'contorizeaza scorul Playerului 2
    Dim count As Integer = 0
    Private Sub winX() ' verifica daca playerul 1 (cel cu X) a castigat.
        'daca a gasit o linie,coloana... marcata cu x , afiseaza textul felicitari 'numele playerului 1'
        'seteaza in verde culoarea de background a butoanelor cu X iar celelalte le dezactiveaza si le seteaza background rosu
        If A1.Text = "X" And A2.Text = "X" And A3.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A1.BackColor = Color.Lime
            A2.BackColor = Color.Lime
            A3.BackColor = Color.Lime
        ElseIf B1.Text = "X" And B2.Text = "X" And B3.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            B1.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            B3.BackColor = Color.Lime
        ElseIf C1.Text = "X" And C2.Text = "X" And C3.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            C1.BackColor = Color.Lime
            C2.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A1.Text = "X" And B1.Text = "X" And C1.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A1.BackColor = Color.Lime
            B1.BackColor = Color.Lime
            C1.BackColor = Color.Lime
        ElseIf A2.Text = "X" And B2.Text = "X" And C2.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A2.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C2.BackColor = Color.Lime
        ElseIf A3.Text = "X" And B3.Text = "X" And C3.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A3.BackColor = Color.Lime
            B3.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A1.Text = "X" And B2.Text = "X" And C3.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A1.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A3.Text = "X" And B2.Text = "X" And C1.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A3.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C1.BackColor = Color.Lime
        End If
        If lblRezultat.Text = "FELICITARI " & lblPlayer.Text Then
            scorX += 1
            Timer1.Stop()
        End If
    End Sub
    Private Sub win0() ' verifica daca playerul 1 (cel cu X) a castigat.
        'daca a gasit o linie,coloana... marcata cu x , afiseaza textul felicitari 'numele playerului 1'
        'seteaza in verde culoarea de background a butoanelor cu X iar celelalte le dezactiveaza si le seteaza background rosu
        If A1.Text = "0" And A2.Text = "0" And A3.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A1.BackColor = Color.Lime
            A2.BackColor = Color.Lime
            A3.BackColor = Color.Lime
        ElseIf B1.Text = "0" And B2.Text = "0" And B3.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            B1.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            B3.BackColor = Color.Lime
        ElseIf C1.Text = "0" And C2.Text = "0" And C3.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            C1.BackColor = Color.Lime
            C2.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A1.Text = "0" And B1.Text = "0" And C1.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A1.BackColor = Color.Lime
            B1.BackColor = Color.Lime
            C1.BackColor = Color.Lime
        ElseIf A2.Text = "0" And B2.Text = "0" And C2.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A2.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C2.BackColor = Color.Lime
        ElseIf A3.Text = "0" And B3.Text = "0" And C3.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A3.BackColor = Color.Lime
            B3.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A1.Text = "0" And B2.Text = "0" And C3.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A1.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A3.Text = "0" And B2.Text = "0" And C1.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A3.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C1.BackColor = Color.Lime
        End If
        If lblRezultat.Text = "FELICITARI " & lblComputer.Text Then
            scor0 += 1
            Timer1.Stop()
        End If
    End Sub

    Private Sub frmComputer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblPlayer.Text = nume
        scor0 = 0
        scorX = 0
        For Each item As Control In Me.Controls
            If TypeOf item Is Button And item.Tag <> "Setting" Then
                item.Tag = "" ' seteaza ca a fost verificat
                item.BackColor = Color.Transparent  'background galben
                item.Text = "" 'textul '0'
            End If
        Next
        lblComputer.Text = "Computer"
        lblRezultat.Text = ""
        Timer1.Start()
    End Sub
    Private Sub Set0(ByVal sender As Button) 'seteaza click 0
        sender.Tag = "Checked" ' seteaza ca a fost verificat
        sender.BackColor = Color.Yellow 'background galben
        sender.Text = "0" 'textul '0'
        sender.FlatAppearance.MouseOverBackColor = Color.Yellow ' daca trece cu mouse-ul peste buton , seteaza background galben
        sender.FlatAppearance.MouseDownBackColor = Color.Yellow ' daca apasa click pe buton , seteaza background galben
        sender.Cursor = Cursors.Default  'cursorul de mouse este default, cum era
    End Sub
    Private Function check_win_block(ByVal strText As String) ' verifica daca poate sa castige ( cand strText="0") sau sa blocheze X (strText="X")
        'verificare pe orizontala
        If A1.Text = strText And A2.Text = strText And A3.Text = "" Then
            Return A3
        ElseIf A2.Text = strText And A3.Text = strText And A1.Text = "" Then
            Return A1
        ElseIf A1.Text = strText And A3.Text = strText And A2.Text = "" Then
            Return A2

        ElseIf B1.Text = strText And B2.Text = strText And B3.Text = "" Then
            Return B3
        ElseIf B2.Text = strText And B3.Text = strText And B1.Text = "" Then
            Return B1
        ElseIf B1.Text = strText And B3.Text = strText And B2.Text = "" Then
            Return B2

        ElseIf C1.Text = strText And C2.Text = strText And C3.Text = "" Then
            Return C3
        ElseIf C2.Text = strText And C3.Text = strText And C1.Text = "" Then
            Return C1

        ElseIf C1.Text = strText And C3.Text = strText And C2.Text = "" Then
            Return C2

            'verificare pe verticala
        ElseIf A1.Text = strText And B1.Text = strText And C1.Text = "" Then
            Return C1

        ElseIf B1.Text = strText And C1.Text = strText And A1.Text = "" Then
            Return A1

        ElseIf A1.Text = strText And C1.Text = strText And B1.Text = "" Then
            Return B1


        ElseIf A2.Text = strText And B2.Text = strText And C2.Text = "" Then
            Return C2

        ElseIf B2.Text = strText And C2.Text = strText And A2.Text = "" Then
            Return A2

        ElseIf A2.Text = strText And C2.Text = strText And B2.Text = "" Then
            Return B2


        ElseIf A3.Text = strText And B3.Text = strText And C3.Text = "" Then
            Return C3

        ElseIf B3.Text = strText And C3.Text = strText And A3.Text = "" Then
            Return A3

        ElseIf A3.Text = strText And C3.Text = strText And B3.Text = "" Then
            Return B3


            'verificare pe diagonala
        ElseIf A1.Text = strText And B2.Text = strText And C3.Text = "" Then
            Return C3

        ElseIf B2.Text = strText And C3.Text = strText And A1.Text = "" Then
            Return A1

        ElseIf A1.Text = strText And C3.Text = strText And B2.Text = "" Then
            Return B2
        End If
        Return Nothing
    End Function
    Private Function check_corner() 'verifica colturile libere si returneaza primul colt liber
        If A1.Text = "0" Then
            If A3.Text = "" Then
                Return A3
            End If
            If C3.Text = "" Then
                Return C3
            End If
            If C1.Text = "" Then
                Return C1
            End If
        End If
        If A3.Text = "0" Then
            If A1.Text = "" Then
                Return A3
            End If
            If C3.Text = "" Then
                Return C3
            End If
            If C1.Text = "" Then
                Return C1
            End If
        End If
        If C3.Text = "0" Then
            If A3.Text = "" Then
                Return A3
            End If
            If C1.Text = "" Then
                Return C1
            End If
            If A1.Text = "" Then
                Return A1
            End If
        End If
        If C1.Text = "0" Then
            If A1.Text = "" Then
                Return A1
            End If
            If A3.Text = "" Then
                Return A3
            End If
            If C3.Text = "" Then
                Return C3
            End If
        End If

        If A1.Text = "" Then
            Return A1
        End If
        If A3.Text = "" Then
            Return A3
        End If
        If C3.Text = "" Then
            Return C3
        End If
        If A3.Text = "" Then
            Return A3
        End If

        Return Nothing
    End Function
    Private Function check_open_space() ' cauta un patrat liber
        Dim temp As Button = Nothing
        For Each item As Control In Me.Controls
            If TypeOf item Is Button And item.Tag <> "Setting" Then 'tag-ul setting sunt cele ce nu fac parte din patrate
                If item.Text = "" Then
                    Return item
                End If
            End If
        Next
        Return Nothing
    End Function
    Private Sub A1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles A1.Click, A2.Click, A3.Click, B1.Click, B2.Click, B3.Click, C1.Click, C2.Click, C3.Click
        'un eveniment la click de mouse ( daca utilizatorul a dat click, se apeleaza aceste eveniment)
        'lblPayer.Enabled= true atunci cand este randul jucatorului cu X sa completeze, altfel este =false
        'lblComputer.Enabled= true atunci cand este randul jucatorului cu 0 sa completeze, altfel este =false
        'atunci cand un buton are tag-ul 'Checked' , inseamna ca a fost marcat cu X sau 0
        If lblPlayer.Enabled = True Then
            If sender.tag <> "Checked" Then
                sender.tag = "Checked" ' seteaza ca a fost verificat
                sender.BackColor = Color.Yellow 'background galben
                sender.Text = "X" 'textul 'X'
                sender.FlatAppearance.MouseOverBackColor = Color.Yellow ' daca trece cu mouse-ul peste buton , seteaza background galben
                sender.FlatAppearance.MouseDownBackColor = Color.Yellow ' daca apasa click pe buton , seteaza background galben
                sender.Cursor = Cursors.Default 'cursorul de mouse este default, cum era
                lblPlayer.Enabled = False
                lblComputer.Enabled = True ' este randul celui de al doilea jucator
                lbl0.Show() 'afiseaza 0
                lblX.Hide() 'ascunde X

            End If
        ElseIf lblComputer.Enabled = True Then
            If sender.tag <> "Checked" Then

                lblComputer.Enabled = False
                lblPlayer.Enabled = True  ' este randul primului jucator

                lblX.Show() 'afiseaza X
                lbl0.Hide() 'ascunde 0
            End If
        End If
    End Sub

    Private Sub reset(ByVal sender As System.Object) 'reseteaza tag-urile, culoarea de background in transparent, elimina X si 0
        sender.tag = ""
        sender.BackColor = Color.Transparent
        sender.Text = ""
        sender.FlatAppearance.MouseOverBackColor = Color.Transparent
        sender.FlatAppearance.MouseDownBackColor = Color.Transparent
        sender.Cursor = Cursors.Hand
        lblComputer.Enabled = False
        lblPlayer.Enabled = True
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click 'reseteaza jocul
        lblRezultat.Text = ""
        cbIncepe0.Checked = False 'folosit pentru a a vedea daca se incepe cu 0 jocul, aici e false
        For Each item As Control In Me.Controls
            If TypeOf item Is Button And item.Tag <> "Setting" Then
                'reseteaza fiecare buton , apeleaza functia reset, exceptie facand Seteaza nume, joc nou si reseteza ( au tag-ul Setting)
                Call reset(item) 'apelare functie reset
                scorX = 0 'scor x =0
                scor0 = 0 'scor 0 =0
            End If
        Next
        lblPlayer0.Text = scor0
        lblPlayerX.Text = scorX
        lbl0.Hide()
        lblX.Show()
        ' mai jos se activeaza toate butoanele
        A1.Enabled = True
        A2.Enabled = True
        A3.Enabled = True
        B1.Enabled = True
        B2.Enabled = True
        B3.Enabled = True
        C1.Enabled = True
        C2.Enabled = True
        C3.Enabled = True
        Timer1.Start()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click 'joc nou
        lblRezultat.Text = ""
        For Each item As Control In Me.Controls
            If TypeOf item Is Button And item.Tag <> "Setting" Then
                'reseteaza fiecare buton , apeleaza functia reset, exceptie facand Seteaza nume, joc nou si reseteza ( au tag-ul Setting)
                Call reset(item)
            End If
        Next

        If cbIncepe0.Checked = True Then 'aici se verifica daca a fost marcat checkboxul 'Incepe cu 0' , daca da, jocul incepe cu 0 ,daca nu ,incepe cu X
            lblPlayer.Enabled = False
            lblComputer.Enabled = True
            lbl0.Show()
            lblX.Hide()
        Else ' incepe cu x
            lblPlayer.Enabled = True
            lblComputer.Enabled = False
            lbl0.Hide()
            lblX.Show()
        End If
        lblPlayerX.Text = scorX
        lblPlayer0.Text = scor0
        'activeaza toate butoanele
        A1.Enabled = True
        A2.Enabled = True
        A3.Enabled = True
        B1.Enabled = True
        B2.Enabled = True
        B3.Enabled = True
        C1.Enabled = True
        C2.Enabled = True
        C3.Enabled = True
        cbIncepe0.Checked = False
        Timer1.Start()
    End Sub
    Private Sub dezactivate() 'dezactiveaza butoanele si seteaza background in rosu, atunci cand s-a terminat jocul ,cineva a castigat
        A1.Enabled = False
        A2.Enabled = False
        A3.Enabled = False
        B1.Enabled = False
        B2.Enabled = False
        B3.Enabled = False
        C1.Enabled = False
        C2.Enabled = False
        C3.Enabled = False
        For Each item As Control In Me.Controls
            If TypeOf item Is Button And item.Tag <> "Setting" Then
                If item.Tag = "Checked" Then
                    item.BackColor = Color.DarkRed
                End If
            End If
        Next
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNume.Click 'aici se seteaza numele jucatorilor
        nume = InputBox("Seteaza nume player ")
        If Not String.IsNullOrEmpty(Trim(nume)) Then 'daca nume nu este vid..
            lblPlayer.Text = nume
        End If
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim move As Button = Nothing
        Call winX() 'verifica daca X a castigat
        Call win0() 'verifica daca 0 a castigat
        If A1.Text <> "" And A2.Text <> "" And A3.Text <> "" Then 'verifica daca a fost remiza
            If B1.Text <> "" And B2.Text <> "" And B3.Text <> "" Then
                If C1.Text <> "" And C2.Text <> "" And C3.Text <> "" Then
                    lblRezultat.Text = "REMIZA.SORRY!"
                    lblRezultat.Show()
                    For Each item As Control In Me.Controls
                        If TypeOf item Is Button And item.Tag <> "Setting" Then
                            item.Enabled = False 'dezactiveaza patratele
                        End If
                    Next
                End If
            End If
        End If
        ' intai comuterul vede daca poate castiga
        ' daca nu ,se uita daca poate sa blocheze pe X
        ' daca nu , verifica un colt liber unde sa marcheze
        ' daca nu este atunci pune unde este liber
        If lblComputer.Enabled = True Then 'daca este randul computerului..
            move = check_win_block("0") 'verifica daca poate castiga
            If move Is Nothing Then
                move = check_win_block("X") ' verifica pentru blocare X
                If move Is Nothing Then
                    move = check_corner() ' verifica pentru colturi libere
                    If move Is Nothing Then
                        move = check_open_space() 'cauta spatii libere
                    End If
                End If
            End If
            If Not move Is Nothing Then
                Call Set0(move) 'verifica butonul sa nu fie vid
            End If
            lblComputer.Enabled = False
            lblPlayer.Enabled = True  ' este randul primului jucator

            lblX.Show() 'afiseaza X
            lbl0.Hide() 'ascunde 0

        End If
    End Sub

    Private Sub btnIesire_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIesire.Click
        Me.Close()
    End Sub
End Class