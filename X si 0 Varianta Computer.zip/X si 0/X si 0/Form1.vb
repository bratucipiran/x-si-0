﻿Public Class frmPlayer
    Dim scorX As Integer = 0 'contorizeaza scorul Playerului 1
    Dim scor0 As Integer = 0 'contorizeaza scorul Playerului 2
    Dim numeX As String ' numele playerului 1
    Dim nume0 As String ' numele playerului 2

    Private Sub winX() ' verifica daca playerul 1 (cel cu X) a castigat.
        'daca a gasit o linie,coloana... marcata cu x , afiseaza textul felicitari 'numele playerului 1'
        'seteaza in verde culoarea de background a butoanelor cu X iar celelalte le dezactiveaza si le seteaza background rosu
        If A1.Text = "X" And A2.Text = "X" And A3.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A1.BackColor = Color.Lime
            A2.BackColor = Color.Lime
            A3.BackColor = Color.Lime
            scorX += 1
        ElseIf B1.Text = "X" And B2.Text = "X" And B3.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            scorX += 1
            Call dezactivate()
            B1.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            B3.BackColor = Color.Lime
        ElseIf C1.Text = "X" And C2.Text = "X" And C3.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            scorX += 1
            Call dezactivate()
            C1.BackColor = Color.Lime
            C2.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A1.Text = "X" And B1.Text = "X" And C1.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            scorX += 1
            Call dezactivate()
            A1.BackColor = Color.Lime
            B1.BackColor = Color.Lime
            C1.BackColor = Color.Lime
        ElseIf A2.Text = "X" And B2.Text = "X" And C2.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            scorX += 1
            Call dezactivate()
            A2.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C2.BackColor = Color.Lime
        ElseIf A3.Text = "X" And B3.Text = "X" And C3.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            scorX += 1
            Call dezactivate()
            A3.BackColor = Color.Lime
            B3.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A1.Text = "X" And B2.Text = "X" And C3.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            scorX += 1
            Call dezactivate()
            A1.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A3.Text = "X" And B2.Text = "X" And C1.Text = "X" Then
            lblRezultat.Text = "FELICITARI " & lblPlayer.Text
            lblRezultat.Visible = True
            scorX += 1
            Call dezactivate()
            A3.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C1.BackColor = Color.Lime
        End If


    End Sub
    Private Sub win0() ' verifica daca playerul 1 (cel cu X) a castigat.
        'daca a gasit o linie,coloana... marcata cu x , afiseaza textul felicitari 'numele playerului 1'
        'seteaza in verde culoarea de background a butoanelor cu X iar celelalte le dezactiveaza si le seteaza background rosu
        If A1.Text = "0" And A2.Text = "0" And A3.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            Call dezactivate()
            A1.BackColor = Color.Lime
            A2.BackColor = Color.Lime
            A3.BackColor = Color.Lime
            scor0 += 1
        ElseIf B1.Text = "0" And B2.Text = "0" And B3.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            scor0 += 1
            Call dezactivate()
            B1.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            B3.BackColor = Color.Lime
        ElseIf C1.Text = "0" And C2.Text = "0" And C3.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            scor0 += 1
            Call dezactivate()
            C1.BackColor = Color.Lime
            C2.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A1.Text = "0" And B1.Text = "0" And C1.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            scor0 += 1
            Call dezactivate()
            A1.BackColor = Color.Lime
            B1.BackColor = Color.Lime
            C1.BackColor = Color.Lime
        ElseIf A2.Text = "0" And B2.Text = "0" And C2.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            scor0 += 1
            Call dezactivate()
            A2.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C2.BackColor = Color.Lime
        ElseIf A3.Text = "0" And B3.Text = "0" And C3.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            scor0 += 1
            Call dezactivate()
            A3.BackColor = Color.Lime
            B3.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A1.Text = "0" And B2.Text = "0" And C3.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            scor0 += 1
            Call dezactivate()
            A1.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C3.BackColor = Color.Lime
        ElseIf A3.Text = "0" And B2.Text = "0" And C1.Text = "0" Then
            lblRezultat.Text = "FELICITARI " & lblComputer.Text
            lblRezultat.Visible = True
            scor0 += 1
            Call dezactivate()
            A3.BackColor = Color.Lime
            B2.BackColor = Color.Lime
            C1.BackColor = Color.Lime
        End If
    End Sub

    Private Sub Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles C3.Click, A1.Click, A2.Click, A3.Click, B1.Click, B2.Click, B3.Click, C1.Click, C2.Click
        'un eveniment la click de mouse ( daca utilizatorul a dat click, se apeleaza aceste eveniment)
        'lblPayer.Enabled= true atunci cand este randul jucatorului cu X sa completeze, altfel este =false
        'lblComputer.Enabled= true atunci cand este randul jucatorului cu 0 sa completeze, altfel este =false
        'atunci cand un buton are tag-ul 'Checked' , inseamna ca a fost marcat cu X sau 0
        If lblPlayer.Enabled = True Then 'randul primului jucator
            If sender.tag <> "Checked" Then
                sender.tag = "Checked" ' seteaza ca a fost verificat
                sender.BackColor = Color.Yellow 'background galben
                sender.Text = "X" 'textul 'X'
                sender.FlatAppearance.MouseOverBackColor = Color.Yellow ' daca trece cu mouse-ul peste buton , seteaza background galben
                sender.FlatAppearance.MouseDownBackColor = Color.Yellow ' daca apasa click pe buton , seteaza background galben
                sender.Cursor = Cursors.Default 'cursorul de mouse este default, cum era
                lblPlayer.Enabled = False
                lblComputer.Enabled = True ' este randul celui de al doilea jucator
                lbl0.Show() 'afiseaza 0
                lblX.Hide() 'ascunde X

            End If
        ElseIf lblComputer.Enabled = True Then 'randul celui de al doilea jucator
            If sender.tag <> "Checked" Then
                sender.tag = "Checked" ' seteaza ca a fost verificat
                sender.BackColor = Color.Yellow 'background galben
                sender.Text = "0" 'textul '0'
                sender.FlatAppearance.MouseOverBackColor = Color.Yellow ' daca trece cu mouse-ul peste buton , seteaza background galben
                sender.FlatAppearance.MouseDownBackColor = Color.Yellow ' daca apasa click pe buton , seteaza background galben
                sender.Cursor = Cursors.Default  'cursorul de mouse este default, cum era
                lblComputer.Enabled = False
                lblPlayer.Enabled = True  ' este randul primului jucator

                lblX.Show() 'afiseaza X
                lbl0.Hide() 'ascunde 0
            End If
        End If
        Call winX() 'verifica daca X a castigat
        Call win0() 'verifica daca 0 a castigat
        If A1.Text <> "" And A2.Text <> "" And A3.Text <> "" And lblRezultat.Text = "" Then 'verifica daca a fost remiza
            If B1.Text <> "" And B2.Text <> "" And B3.Text <> "" Then
                If C1.Text <> "" And C2.Text <> "" And C3.Text <> "" Then
                    lblRezultat.Text = "REMIZA.SORRY!"
                    lblRezultat.Show()
                End If
            End If
        End If


    End Sub


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblPlayerX.Text = scorX 'seteaza scorul x
        lblPlayer0.Text = scor0 'seteaza scorul y
        lblRezultat.Text = ""
        For Each item As Control In Me.Controls
            If TypeOf item Is Button And item.Tag <> "Setting" Then
                item.Tag = "" ' seteaza ca a fost verificat
                item.BackColor = Color.Transparent  'background galben
                item.Text = "" 'textul '0'
            End If
        Next
        scor0 = 0
        scorX = 0
    End Sub
    Private Sub reset(ByVal sender As System.Object) 'reseteaza tag-urile, culoarea de background in transparent, elimina X si 0
        sender.tag = ""
        sender.BackColor = Color.Transparent
        sender.Text = ""
        sender.FlatAppearance.MouseOverBackColor = Color.Transparent
        sender.FlatAppearance.MouseDownBackColor = Color.Transparent
        sender.Cursor = Cursors.Hand
        lblComputer.Enabled = False
        lblPlayer.Enabled = True
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        lblRezultat.Text = ""
        cbIncepe0.Checked = False 'folosit pentru a a vedea daca se incepe cu 0 jocul, aici e false
        For Each item As Control In Me.Controls
            If TypeOf item Is Button And item.Tag <> "Setting" Then
                'reseteaza fiecare buton , apeleaza functia reset, exceptie facand Seteaza nume, joc nou si reseteza ( au tag-ul Setting)
                Call reset(item) 'apelare functie reset
                scorX = 0 'scor x =0
                scor0 = 0 'scor 0 =0
            End If
        Next
        lblPlayer0.Text = scor0
        lblPlayerX.Text = scorX
        lbl0.Hide()
        lblX.Show()
        ' mai jos se activeaza toate butoanele
        A1.Enabled = True
        A2.Enabled = True
        A3.Enabled = True
        B1.Enabled = True
        B2.Enabled = True
        B3.Enabled = True
        C1.Enabled = True
        C2.Enabled = True
        C3.Enabled = True
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click 'joc nou
        lblRezultat.Text = ""
        For Each item As Control In Me.Controls
            If TypeOf item Is Button And item.Tag <> "Setting" Then
                'reseteaza fiecare buton , apeleaza functia reset, exceptie facand Seteaza nume, joc nou si reseteza ( au tag-ul Setting)
                Call reset(item)
            End If
        Next

        If cbIncepe0.Checked = True Then 'aici se verifica daca a fost marcat checkboxul 'Incepe cu 0' , daca da, jocul incepe cu 0 ,daca nu ,incepe cu X
            lblPlayer.Enabled = False
            lblComputer.Enabled = True
            lbl0.Show()
            lblX.Hide()
        Else ' incepe cu x
            lblPlayer.Enabled = True
            lblComputer.Enabled = False
            lbl0.Hide()
            lblX.Show()
        End If
        lblPlayerX.Text = scorX
        lblPlayer0.Text = scor0
        'activeaza toate butoanele
        A1.Enabled = True
        A2.Enabled = True
        A3.Enabled = True
        B1.Enabled = True
        B2.Enabled = True
        B3.Enabled = True
        C1.Enabled = True
        C2.Enabled = True
        C3.Enabled = True
        cbIncepe0.Checked = False
    End Sub
    Private Sub dezactivate() 'dezactiveaza butoanele si seteaza background in rosu, atunci cand s-a terminat jocul ,cineva a castigat
        A1.Enabled = False
        A2.Enabled = False
        A3.Enabled = False
        B1.Enabled = False
        B2.Enabled = False
        B3.Enabled = False
        C1.Enabled = False
        C2.Enabled = False
        C3.Enabled = False
        For Each item As Control In Me.Controls
            If TypeOf item Is Button And item.Tag <> "Setting" Then
                If item.Tag = "Checked" Then
                    item.BackColor = Color.DarkRed
                End If
            End If
        Next
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNume.Click 'aici se seteaza numele jucatorilor
        numeX = InputBox("Seteaza nume player 1")
        nume0 = InputBox("Seteaza nume player 2")
        If Not String.IsNullOrEmpty(Trim(numeX)) Then
            lblPlayer.Text = numeX
        End If
        If Not String.IsNullOrEmpty(Trim(nume0)) Then
            lblComputer.Text = nume0
        End If

    End Sub

    Private Sub btnIesire_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIesire.Click
        Me.Close()
    End Sub
End Class
