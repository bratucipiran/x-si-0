﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmComputer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmComputer))
        Me.lblPlayer0 = New System.Windows.Forms.Label()
        Me.lblX = New System.Windows.Forms.Label()
        Me.lblPlayerX = New System.Windows.Forms.Label()
        Me.lblRezultat = New System.Windows.Forms.Label()
        Me.btnNume = New System.Windows.Forms.Button()
        Me.lbl0 = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.lblComputer = New System.Windows.Forms.Label()
        Me.cbIncepe0 = New System.Windows.Forms.CheckBox()
        Me.lblPlayer = New System.Windows.Forms.Label()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.gbScor = New System.Windows.Forms.GroupBox()
        Me.C2 = New System.Windows.Forms.Button()
        Me.C1 = New System.Windows.Forms.Button()
        Me.B3 = New System.Windows.Forms.Button()
        Me.B2 = New System.Windows.Forms.Button()
        Me.B1 = New System.Windows.Forms.Button()
        Me.A3 = New System.Windows.Forms.Button()
        Me.A2 = New System.Windows.Forms.Button()
        Me.A1 = New System.Windows.Forms.Button()
        Me.C3 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btnIesire = New System.Windows.Forms.Button()
        Me.gbScor.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblPlayer0
        '
        Me.lblPlayer0.AutoSize = True
        Me.lblPlayer0.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblPlayer0.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.lblPlayer0.ForeColor = System.Drawing.Color.White
        Me.lblPlayer0.Location = New System.Drawing.Point(250, 118)
        Me.lblPlayer0.Name = "lblPlayer0"
        Me.lblPlayer0.Size = New System.Drawing.Size(35, 37)
        Me.lblPlayer0.TabIndex = 12
        Me.lblPlayer0.Text = "0"
        '
        'lblX
        '
        Me.lblX.AutoSize = True
        Me.lblX.Font = New System.Drawing.Font("Algerian", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblX.ForeColor = System.Drawing.Color.NavajoWhite
        Me.lblX.Location = New System.Drawing.Point(6, 44)
        Me.lblX.Name = "lblX"
        Me.lblX.Size = New System.Drawing.Size(37, 35)
        Me.lblX.TabIndex = 17
        Me.lblX.Text = "X"
        '
        'lblPlayerX
        '
        Me.lblPlayerX.AutoSize = True
        Me.lblPlayerX.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblPlayerX.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.lblPlayerX.ForeColor = System.Drawing.Color.White
        Me.lblPlayerX.Location = New System.Drawing.Point(250, 42)
        Me.lblPlayerX.Name = "lblPlayerX"
        Me.lblPlayerX.Size = New System.Drawing.Size(35, 37)
        Me.lblPlayerX.TabIndex = 11
        Me.lblPlayerX.Text = "0"
        '
        'lblRezultat
        '
        Me.lblRezultat.AutoSize = True
        Me.lblRezultat.Font = New System.Drawing.Font("Algerian", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRezultat.ForeColor = System.Drawing.Color.Cornsilk
        Me.lblRezultat.Location = New System.Drawing.Point(165, 19)
        Me.lblRezultat.Name = "lblRezultat"
        Me.lblRezultat.Size = New System.Drawing.Size(282, 54)
        Me.lblRezultat.TabIndex = 30
        Me.lblRezultat.Text = "FELICITARI"
        Me.lblRezultat.Visible = False
        '
        'btnNume
        '
        Me.btnNume.Location = New System.Drawing.Point(12, 19)
        Me.btnNume.Name = "btnNume"
        Me.btnNume.Size = New System.Drawing.Size(126, 32)
        Me.btnNume.TabIndex = 29
        Me.btnNume.Tag = "Setting"
        Me.btnNume.Text = "Seteaza nume"
        Me.btnNume.UseVisualStyleBackColor = True
        '
        'lbl0
        '
        Me.lbl0.AutoSize = True
        Me.lbl0.Font = New System.Drawing.Font("Algerian", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl0.ForeColor = System.Drawing.Color.NavajoWhite
        Me.lbl0.Location = New System.Drawing.Point(6, 120)
        Me.lbl0.Name = "lbl0"
        Me.lbl0.Size = New System.Drawing.Size(34, 35)
        Me.lbl0.TabIndex = 18
        Me.lbl0.Text = "0"
        Me.lbl0.Visible = False
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(79, 479)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(213, 39)
        Me.btnReset.TabIndex = 28
        Me.btnReset.Tag = "Setting"
        Me.btnReset.Text = "RESETEAZA SCOR"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'lblComputer
        '
        Me.lblComputer.Enabled = False
        Me.lblComputer.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.lblComputer.ForeColor = System.Drawing.Color.Yellow
        Me.lblComputer.Location = New System.Drawing.Point(46, 118)
        Me.lblComputer.Name = "lblComputer"
        Me.lblComputer.Size = New System.Drawing.Size(198, 37)
        Me.lblComputer.TabIndex = 10
        Me.lblComputer.Text = "Player 2 "
        '
        'cbIncepe0
        '
        Me.cbIncepe0.AutoSize = True
        Me.cbIncepe0.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.cbIncepe0.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.cbIncepe0.Location = New System.Drawing.Point(79, 439)
        Me.cbIncepe0.Name = "cbIncepe0"
        Me.cbIncepe0.Size = New System.Drawing.Size(81, 21)
        Me.cbIncepe0.TabIndex = 31
        Me.cbIncepe0.Text = "Incepe 0"
        Me.cbIncepe0.UseVisualStyleBackColor = True
        '
        'lblPlayer
        '
        Me.lblPlayer.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblPlayer.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.lblPlayer.ForeColor = System.Drawing.Color.Yellow
        Me.lblPlayer.Location = New System.Drawing.Point(46, 42)
        Me.lblPlayer.Name = "lblPlayer"
        Me.lblPlayer.Size = New System.Drawing.Size(198, 37)
        Me.lblPlayer.TabIndex = 9
        Me.lblPlayer.Text = "Player 1 "
        '
        'btnNew
        '
        Me.btnNew.Location = New System.Drawing.Point(79, 394)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(213, 39)
        Me.btnNew.TabIndex = 27
        Me.btnNew.Tag = "Setting"
        Me.btnNew.Text = "JOC NOU"
        Me.btnNew.UseVisualStyleBackColor = True
        '
        'gbScor
        '
        Me.gbScor.Controls.Add(Me.lbl0)
        Me.gbScor.Controls.Add(Me.lblPlayer0)
        Me.gbScor.Controls.Add(Me.lblX)
        Me.gbScor.Controls.Add(Me.lblPlayerX)
        Me.gbScor.Controls.Add(Me.lblPlayer)
        Me.gbScor.Controls.Add(Me.lblComputer)
        Me.gbScor.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.gbScor.ForeColor = System.Drawing.Color.OrangeRed
        Me.gbScor.Location = New System.Drawing.Point(431, 95)
        Me.gbScor.Name = "gbScor"
        Me.gbScor.Size = New System.Drawing.Size(311, 239)
        Me.gbScor.TabIndex = 26
        Me.gbScor.TabStop = False
        Me.gbScor.Text = "SCOR"
        '
        'C2
        '
        Me.C2.BackColor = System.Drawing.Color.Transparent
        Me.C2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.C2.FlatAppearance.BorderColor = System.Drawing.Color.Beige
        Me.C2.FlatAppearance.BorderSize = 2
        Me.C2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.C2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.C2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.C2.Font = New System.Drawing.Font("Arial Narrow", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.C2.ForeColor = System.Drawing.Color.DarkOrange
        Me.C2.Location = New System.Drawing.Point(186, 265)
        Me.C2.Name = "C2"
        Me.C2.Size = New System.Drawing.Size(101, 79)
        Me.C2.TabIndex = 25
        Me.C2.UseVisualStyleBackColor = False
        '
        'C1
        '
        Me.C1.BackColor = System.Drawing.Color.Transparent
        Me.C1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.C1.FlatAppearance.BorderColor = System.Drawing.Color.Beige
        Me.C1.FlatAppearance.BorderSize = 2
        Me.C1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.C1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.C1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.C1.Font = New System.Drawing.Font("Arial Narrow", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.C1.ForeColor = System.Drawing.Color.DarkOrange
        Me.C1.Location = New System.Drawing.Point(79, 265)
        Me.C1.Name = "C1"
        Me.C1.Size = New System.Drawing.Size(101, 79)
        Me.C1.TabIndex = 24
        Me.C1.UseVisualStyleBackColor = False
        '
        'B3
        '
        Me.B3.BackColor = System.Drawing.Color.Transparent
        Me.B3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.B3.FlatAppearance.BorderColor = System.Drawing.Color.Beige
        Me.B3.FlatAppearance.BorderSize = 2
        Me.B3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.B3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.B3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.B3.Font = New System.Drawing.Font("Arial Narrow", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.B3.ForeColor = System.Drawing.Color.DarkOrange
        Me.B3.Location = New System.Drawing.Point(293, 180)
        Me.B3.Name = "B3"
        Me.B3.Size = New System.Drawing.Size(101, 79)
        Me.B3.TabIndex = 23
        Me.B3.UseVisualStyleBackColor = False
        '
        'B2
        '
        Me.B2.BackColor = System.Drawing.Color.Transparent
        Me.B2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.B2.FlatAppearance.BorderColor = System.Drawing.Color.Beige
        Me.B2.FlatAppearance.BorderSize = 2
        Me.B2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.B2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.B2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.B2.Font = New System.Drawing.Font("Arial Narrow", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.B2.ForeColor = System.Drawing.Color.DarkOrange
        Me.B2.Location = New System.Drawing.Point(186, 180)
        Me.B2.Name = "B2"
        Me.B2.Size = New System.Drawing.Size(101, 79)
        Me.B2.TabIndex = 22
        Me.B2.UseVisualStyleBackColor = False
        '
        'B1
        '
        Me.B1.BackColor = System.Drawing.Color.Transparent
        Me.B1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.B1.FlatAppearance.BorderColor = System.Drawing.Color.Beige
        Me.B1.FlatAppearance.BorderSize = 2
        Me.B1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.B1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.B1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.B1.Font = New System.Drawing.Font("Arial Narrow", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.B1.ForeColor = System.Drawing.Color.DarkOrange
        Me.B1.Location = New System.Drawing.Point(79, 180)
        Me.B1.Name = "B1"
        Me.B1.Size = New System.Drawing.Size(101, 79)
        Me.B1.TabIndex = 21
        Me.B1.UseVisualStyleBackColor = False
        '
        'A3
        '
        Me.A3.BackColor = System.Drawing.Color.Transparent
        Me.A3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.A3.FlatAppearance.BorderColor = System.Drawing.Color.Beige
        Me.A3.FlatAppearance.BorderSize = 2
        Me.A3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.A3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.A3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.A3.Font = New System.Drawing.Font("Arial Narrow", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.A3.ForeColor = System.Drawing.Color.DarkOrange
        Me.A3.Location = New System.Drawing.Point(293, 95)
        Me.A3.Name = "A3"
        Me.A3.Size = New System.Drawing.Size(101, 79)
        Me.A3.TabIndex = 20
        Me.A3.UseVisualStyleBackColor = False
        '
        'A2
        '
        Me.A2.BackColor = System.Drawing.Color.Transparent
        Me.A2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.A2.FlatAppearance.BorderColor = System.Drawing.Color.Beige
        Me.A2.FlatAppearance.BorderSize = 2
        Me.A2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.A2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.A2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.A2.Font = New System.Drawing.Font("Arial Narrow", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.A2.ForeColor = System.Drawing.Color.DarkOrange
        Me.A2.Location = New System.Drawing.Point(186, 95)
        Me.A2.Name = "A2"
        Me.A2.Size = New System.Drawing.Size(101, 79)
        Me.A2.TabIndex = 19
        Me.A2.UseVisualStyleBackColor = False
        '
        'A1
        '
        Me.A1.BackColor = System.Drawing.Color.Transparent
        Me.A1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.A1.FlatAppearance.BorderColor = System.Drawing.Color.Beige
        Me.A1.FlatAppearance.BorderSize = 2
        Me.A1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.A1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.A1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.A1.Font = New System.Drawing.Font("Arial Narrow", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.A1.ForeColor = System.Drawing.Color.DarkOrange
        Me.A1.Location = New System.Drawing.Point(79, 95)
        Me.A1.Name = "A1"
        Me.A1.Size = New System.Drawing.Size(101, 79)
        Me.A1.TabIndex = 18
        Me.A1.UseVisualStyleBackColor = False
        '
        'C3
        '
        Me.C3.BackColor = System.Drawing.Color.Transparent
        Me.C3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.C3.FlatAppearance.BorderColor = System.Drawing.Color.Beige
        Me.C3.FlatAppearance.BorderSize = 2
        Me.C3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.C3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.C3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.C3.Font = New System.Drawing.Font("Arial Narrow", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.C3.ForeColor = System.Drawing.Color.DarkOrange
        Me.C3.Location = New System.Drawing.Point(293, 265)
        Me.C3.Name = "C3"
        Me.C3.Size = New System.Drawing.Size(101, 79)
        Me.C3.TabIndex = 17
        Me.C3.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 1
        '
        'btnIesire
        '
        Me.btnIesire.Location = New System.Drawing.Point(431, 549)
        Me.btnIesire.Name = "btnIesire"
        Me.btnIesire.Size = New System.Drawing.Size(114, 29)
        Me.btnIesire.TabIndex = 35
        Me.btnIesire.Tag = "Setting"
        Me.btnIesire.Text = "IESIRE"
        Me.btnIesire.UseVisualStyleBackColor = True
        '
        'frmComputer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(793, 610)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnIesire)
        Me.Controls.Add(Me.lblRezultat)
        Me.Controls.Add(Me.btnNume)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.cbIncepe0)
        Me.Controls.Add(Me.btnNew)
        Me.Controls.Add(Me.gbScor)
        Me.Controls.Add(Me.C2)
        Me.Controls.Add(Me.C1)
        Me.Controls.Add(Me.B3)
        Me.Controls.Add(Me.B2)
        Me.Controls.Add(Me.B1)
        Me.Controls.Add(Me.A3)
        Me.Controls.Add(Me.A2)
        Me.Controls.Add(Me.A1)
        Me.Controls.Add(Me.C3)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmComputer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "X & 0"
        Me.gbScor.ResumeLayout(False)
        Me.gbScor.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblPlayer0 As System.Windows.Forms.Label
    Friend WithEvents lblX As System.Windows.Forms.Label
    Friend WithEvents lblPlayerX As System.Windows.Forms.Label
    Friend WithEvents lblRezultat As System.Windows.Forms.Label
    Friend WithEvents btnNume As System.Windows.Forms.Button
    Friend WithEvents lbl0 As System.Windows.Forms.Label
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents lblComputer As System.Windows.Forms.Label
    Friend WithEvents cbIncepe0 As System.Windows.Forms.CheckBox
    Friend WithEvents lblPlayer As System.Windows.Forms.Label
    Friend WithEvents btnNew As System.Windows.Forms.Button
    Friend WithEvents gbScor As System.Windows.Forms.GroupBox
    Friend WithEvents C2 As System.Windows.Forms.Button
    Friend WithEvents C1 As System.Windows.Forms.Button
    Friend WithEvents B3 As System.Windows.Forms.Button
    Friend WithEvents B2 As System.Windows.Forms.Button
    Friend WithEvents B1 As System.Windows.Forms.Button
    Friend WithEvents A3 As System.Windows.Forms.Button
    Friend WithEvents A2 As System.Windows.Forms.Button
    Friend WithEvents A1 As System.Windows.Forms.Button
    Friend WithEvents C3 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents btnIesire As System.Windows.Forms.Button
End Class
